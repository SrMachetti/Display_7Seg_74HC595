/*
                  Biblioteca Display 7 Segmentos com CI 74HC595

        Autor: Sérgio Ricardo Marchetti
        Janeiro 2021

        Esta biblioteca tem como objetivo facilitar a ligação de um display
        de 7 segmentos com o CI 74HC595

        Os display serão acesos de forma multiplexada utilizando o timer2
        do arduino

*/

#include "Display_7Seg_74HC595.h"
//Display_7Seg_74HC595 Display1;

ISR(TIMER2_OVF_vect)
{
  //TCNT2 = 192; //192

  // Display1.isrCallback();
  Display1.imprimeDisplay();
}

Display_7Seg_74HC595::Display_7Seg_74HC595 (uint8_t QtDisplay, bool cathode)
{
  SPI.begin ();
  digitalWrite (SS, HIGH);
  if (cathode)
  {
    //_Gate[_QtdDisplay + 1] = { 0xFE, 0xFD, 0xFB, 0xF7, 0xFF};
    //Anode commom
    _digito[0] = 0x3F;
    _digito[1] = 0x06;
    _digito[2] = 0x5B;
    _digito[3] = 0X4F;
    _digito[4] = 0x66;
    _digito[5] = 0x6D;
    _digito[6] = 0x7D;
    _digito[7] = 0x07;
    _digito[8] = 0x7F;
    _digito[9] = 0x6F;

    _Gate[0] = 0xFE;
    _Gate[1] = 0xFD;
    _Gate[2] = 0xFB;
    _Gate[3] = 0xF7;
    _Gate[4] = 0xFF;
    //_Gate[_QtdDisplay + 1] = { 0xFE, 0xFD, 0xFB, 0xF7, 0xFF};


  }
  else
  {
    _digito[0] = 0xC0;
    _digito[1] =  0xF9;
    _digito[2] =  0xA4;
    _digito[3] =  0xB0;
    _digito[4] =  0x99;
    _digito[5] =  0x92;
    _digito[6] =  0x82;
    _digito[7] =  0xF8;
    _digito[8] =  0x80;
    _digito[9] =  0x90;


    _Gate[0] = 0x01;
    _Gate[1] = 0x02;
    _Gate[2] = 0x04;
    _Gate[3] = 0x08;
    _Gate[4] = 0x00;
    //_Gate[_QtdDisplay + 1] = { 0xFE, 0xFD, 0xFB, 0xF7, 0xFF};
  }

  _QtDisplay = QtDisplay;

  //  _disp[_contaObjeto] = "display";
  //_contaObjeto++

  TCCR2A = 0x00; //Timer operando em modo normal
  TCCR2B = 0X05; //Preescaler 1:1024
  TIMSK2 = 0x01; //Habilita a interrupção do timer2

  //TCNT2  = 192;   // 4ms overflow again 192
  //TIMSK2 = 0x01; //Habilita a interrupção do timer2

}

void Display_7Seg_74HC595::imprimeDisplay()
{
  static byte nDigito = _QtDisplay;
  nDigito--;
  digitalWrite(SS, LOW);
  SPI.transfer ( _Gate[nDigito]);  //[_QtDisplay - 1 - nDigito];
  if (_ponto == nDigito) SPI.transfer ( _digito[_valores[nDigito]] + 128);
  else SPI.transfer ( _digito[_valores[nDigito]]);
  digitalWrite(SS, HIGH);
  if (nDigito == 0) nDigito = _QtDisplay;

}

void Display_7Seg_74HC595::printInt (uint32_t vlr)
{
  _ponto = 99;
  for (byte i = _QtDisplay ; i > 0; i--) {
    _valores[i - 1] = vlr % 10;
    vlr /= 10;
  }

}

void Display_7Seg_74HC595::printFloat (float vlr)
{

  byte c;
  char valorch[_QtDisplay];
  _ponto = 0;
  dtostrf(vlr, 1, 3, valorch);
  byte n = 0;
  for (const char * p = valorch; c = *p; p++) {
    if (c != 46) {
      _valores[n]  = c - 48;
      n++;
    }
    else {
      _ponto = n - 1 ;
    }
  }

}

void Display_7Seg_74HC595::attachInterrupt(void (*isr)())
{
  TIMSK2 = 0x01; //Habilita a interrupção do timer2

  isrCallback = isr;                                       // register the user's callback with the real ISR
  //resume();
}
