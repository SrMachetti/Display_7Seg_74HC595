/*
                  Biblioteca Display 7 Segmentos com CI 74HC595

        Autor: Sérgio Ricardo Marchetti
        Fevereiro 2021
        Versão 0.3

        Esta biblioteca tem como objetivo facilitar a ligação de um display
        de 7 segmentos com o CI 74HC595

        Os display serão acesos de forma multiplexada utilizando o timer2
        do arduino

        Novidades V 0.3
        Resolução de bug de ponto flutuante em display Cathodo comum
        Definir os tipos de display de foma mais intuitica com COMMON_CATHODE e COMMON_ANODE

        Novidades v 0.2
        alteração no código para utilizar registradores
        Resolvido problemas para ligar em simultâneo outro dispositivo SPI
        Incusão da função Begin e stop para poder usar mais de um dispositivo SPI


*/

#include "Display_7Seg_74HC595.h"

ISR(TIMER2_OVF_vect)
{
  Display1.imprimeDisplay(); //Chama a classe para imprimir 1 digito a cada estouro do timer
}

Display_7Seg_74HC595::Display_7Seg_74HC595 (uint8_t QtDisplay, int displayType)
{
  SPI.begin ();                             //inicia comunicação SPI
  pinMode (SS, OUTPUT);                     //Chip Select padrão pino 10
  digitalWrite (SS, HIGH);                  //poe o Chipselect em HIGH
  _displayType = displayType;               
  _clearGate = _displayType ? 0xFF : 0x00;  //limpa todos os displays de acordo com o tipo
  if (!_displayType) {                      //inverte os digitos para anodo comum
    for (int i = 0; i < 10; i++) { //inverte os displays para Anodo comum
      _digito[i] = ~_digito[i];    //^= 0xFF;
    }
  }

  _QtDisplay = QtDisplay;
}

void Display_7Seg_74HC595::begin ()
{
  TCCR2A = 0x00; //Timer operando em modo normal
  TCCR2B = 0X05; //Preescaler 1:128 (estouro a cada 4 milli segundos)
  TIMSK2 = 0x01; //Habilita a interrupção do timer2
  SPI.setClockDivider(1);
}

void Display_7Seg_74HC595::stop () 
{
  PORTB &= ~(1 << 2);
  _gate = _clearGate; //limpa os dígitos
  SPI.transfer ( _gate);  //limpa display
  SPI.transfer ( _gate); //Limpa display
  PORTB |= (1 << 2);
  TIMSK2 = 0x00; //Habilita a interrupção do timer2

}

void Display_7Seg_74HC595::imprimeDisplay()
{
  static byte nDigito = _QtDisplay;
  nDigito--;
  PORTB &= ~(1 << 2); //coloca o pino 10 em LOW
  _gate = _clearGate; //limpa os dígitos
  _gate ^= (1 << nDigito); //seta o dígito a ser aceso
  SPI.transfer ( _gate);  //[_QtDisplay - 1 - nDigito]; // liga o dígito
  SPI.transfer ( (_ponto == nDigito) ? _digito[_valores[nDigito]] ^ (1 << 7) : _digito[_valores[nDigito]]);
  PORTB |= (1 << 2); //Coloca o pino 10 em HIGH
  if (nDigito == 0) nDigito = _QtDisplay;
}

void Display_7Seg_74HC595::printInt (uint32_t vlr)
{
  _ponto = 999;
  for (byte i = _QtDisplay ; i > 0; i--) {
    _valores[i - 1] = vlr % 10;
    vlr /= 10;
  }
}

void Display_7Seg_74HC595::printFloat (float vlr)
{
  byte c;
  char valorch[_QtDisplay];
  dtostrf(vlr, 2, 3, valorch); //converte a variável em Char
  byte n = 0;
  for (const char *p = valorch; c = *p; p++) {
    if (c != 46) {
      _valores[n]  = c - 48;
      n++;
    }
    else {
      _ponto = n - 1 ;
    }
  }
}

void Display_7Seg_74HC595::attachInterrupt(void (*isr)())
{
  TIMSK2 = 0x01; //Habilita a interrupção do timer2

  isrCallback = isr;                                       // register the user's callback with the real ISR
  //resume();
}
