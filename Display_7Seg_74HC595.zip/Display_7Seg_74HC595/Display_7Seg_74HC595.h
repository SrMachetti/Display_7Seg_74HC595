/*
                  Biblioteca Display 7 Segmentos com CI 74HC595

        Autor: Sérgio Ricardo Marchetti
        Fevereiro 2021
        Versão 0.3

        Esta biblioteca tem como objetivo facilitar a ligação de um display
        de 7 segmentos com o CI 74HC595

        Os display serão acesos de forma multiplexada utilizando o timer2
        do arduino

        Novidades V 0.3
        Resolução de bug de ponto flutuante em display Cathodo comum
        Definir os tipos de display de foma mais intuitica com COMMON_CATHODE e COMMON_ANODE

        Novidades v 0.2
        alteração no código para utilizar registradores
        Resolvido problemas para ligar em simultâneo outro dispositivo SPI
        Incusão da função Begin e stop para poder usar mais de um dispositivo SPI

*/

#ifndef Display_7Seg_74HC595_h
#define Display_7Seg_74HC595_h
#include <Arduino.h>
#include <SPI.h>


#include <avr/io.h>
#include <avr/interrupt.h>
const int COMMON_ANODE = 0;
const int COMMON_CATHODE = 1;

class Display_7Seg_74HC595
{
    //======================Classes Publicas==========================
  public:
    Display_7Seg_74HC595 ( uint8_t QtDisplay, int displayType);

    void printInt (uint32_t valor);
    void printFloat (float valor);
    void begin ();
    void stop ();
    void imprimeDisplay( );

    void attachInterrupt(void (*isr)());
    void (*isrCallback)();

    //=====================Variáveis Privadas===========================
  private:
    uint32_t _valor;      //valor a ser impresso
    uint8_t _clearGate;   //desativa todos os displays
    uint8_t _ponto;       //Variável para determinar o ponto decimal
    uint8_t _digito[10] = //7 segmentos de A a G
    {
      0x3F, 0x06, 0x5B, 0X4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F
    };
    uint8_t _valores[10]; //valor a ser impresso
    uint8_t  _gate;       //display a ser ligado
    uint8_t _QtDisplay = 0;
    bool _displayType;    //tipo de display 1=Cathodo 0=Anodo
};


extern Display_7Seg_74HC595 Display1;
#endif
