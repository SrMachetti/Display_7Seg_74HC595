/*
                  Biblioteca Display 7 Segmentos com CI 74HC595

        Autor: Sérgio Ricardo Marchetti
        Janeiro 2021

        Esta biblioteca tem como objetivo facilitar a ligação de um display
        de 7 segmentos com o CI 74HC595

        Os display serão acesos de forma multiplexada utilizando o timer2
        do arduino

*/

#ifndef Display_7Seg_74HC595_h
#define Display_7Seg_74HC595_h
#include <Arduino.h>
#include <SPI.h>


#include <avr/io.h>
#include <avr/interrupt.h>


class Display_7Seg_74HC595
{
  public:
    Display_7Seg_74HC595 ( uint8_t QtDisplay, bool cathode);

    void printInt (uint32_t valor);
    void printFloat (float valor);
    void stop ();
    void imprimeDisplay( );

    void attachInterrupt(void (*isr)());
    void (*isrCallback)();


  private:
    uint32_t _valor;

    uint8_t _ponto;
    uint8_t _digito[10];
    uint8_t _valores[10];
    uint8_t  _Gate[5];
    uint8_t _QtDisplay = 0;
};
//uint8_t _contaObjeto = 0;
//String _disp [];

extern Display_7Seg_74HC595 Display1;
#endif
